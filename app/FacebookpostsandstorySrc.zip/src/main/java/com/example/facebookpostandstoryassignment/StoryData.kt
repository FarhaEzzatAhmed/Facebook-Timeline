package com.example.facebookpostandstoryassignment

data class StoryData(
    val storyImg : Int,
    val topImg : Int,
    val personName :String



)
