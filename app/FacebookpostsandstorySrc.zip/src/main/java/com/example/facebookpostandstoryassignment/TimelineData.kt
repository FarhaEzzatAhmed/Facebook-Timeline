package com.example.facebookpostandstoryassignment

data class TimelineData(

    val postAuthor : String,
    val postAuthourImage : Int,
    val uploadData : String,
    val postDescription: String,
    val postImage :Int,
    val like :String

)
